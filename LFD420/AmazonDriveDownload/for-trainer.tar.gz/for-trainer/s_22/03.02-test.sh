set -x
cat /proc/swaps

cat /proc/meminfo
set +x
