make clean
make C=2 CHECK=/usr/bin/sparse
