HERE=$(pwd)

set -x
sudo apt-get install stress stress-ng
set +x

cd ${HERE}
