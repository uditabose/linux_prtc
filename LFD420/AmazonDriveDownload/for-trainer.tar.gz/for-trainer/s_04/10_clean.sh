#!/bin/bash
pushd lab-2
./10_clean.sh
popd
