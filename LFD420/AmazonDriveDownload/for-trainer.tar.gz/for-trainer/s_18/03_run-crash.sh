sudo crash ${KROOT}/vmlinux
