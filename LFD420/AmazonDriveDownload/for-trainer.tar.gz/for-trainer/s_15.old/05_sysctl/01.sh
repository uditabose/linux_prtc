sysctl -a
