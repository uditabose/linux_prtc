man 8 sysctl
