vim /etc/sysctl.conf
