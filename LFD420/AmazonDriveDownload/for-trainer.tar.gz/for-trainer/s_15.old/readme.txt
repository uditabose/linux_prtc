show

nm -n 
objdump -h 

find text section start ....

on ../s_07/linux2.6/vmlinux

