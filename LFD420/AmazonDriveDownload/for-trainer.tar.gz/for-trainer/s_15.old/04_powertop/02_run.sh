sudo powertop
