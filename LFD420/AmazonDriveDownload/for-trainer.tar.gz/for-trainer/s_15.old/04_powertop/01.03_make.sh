HERE=(`pwd`)

cd powertop-1.13
make

cd ${HERE}
