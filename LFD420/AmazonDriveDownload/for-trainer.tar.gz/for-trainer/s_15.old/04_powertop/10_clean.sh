rm -rf powertop-1.13
rm -f powertop-1.13.tar.gz
