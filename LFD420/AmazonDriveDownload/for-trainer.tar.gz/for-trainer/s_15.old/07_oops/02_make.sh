make clean
make 
