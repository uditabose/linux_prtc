git clone git://sources.redhat.com/git/systemtap.git
