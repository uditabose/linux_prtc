rm -rf systemtap
