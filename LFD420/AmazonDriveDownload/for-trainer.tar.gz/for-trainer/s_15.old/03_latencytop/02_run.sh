sudo latencytop
