HERE=(`pwd`)
cd latencytop
git am ../0001-fix-kernel-warning-to-use-tracing_on-instead-of-trac.patch
cd ${HERE}
