rm -rf latencytop
