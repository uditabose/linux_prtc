TMP_PATH=`pwd`
cd latencytop/src
sudo make install
cd ${TMP_PATH}
