sudo apt-get remove latencytop
sudo apt-get install libncursesw5-dev
