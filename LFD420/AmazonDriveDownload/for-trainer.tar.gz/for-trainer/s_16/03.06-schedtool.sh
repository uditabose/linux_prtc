sudo apt-get install schedtool
