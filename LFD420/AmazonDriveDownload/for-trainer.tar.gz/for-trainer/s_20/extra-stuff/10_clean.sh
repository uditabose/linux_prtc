source ../../env.sh
make clean
rm -f Makefile
