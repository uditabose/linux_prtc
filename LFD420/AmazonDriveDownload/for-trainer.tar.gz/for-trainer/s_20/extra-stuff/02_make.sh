make clean
if make ; then
  ./sign-all.sh
fi
