make clean
./01_genmake.sh
rm -f Makefile
