set -x
size lab3_module1.ko
set +x
