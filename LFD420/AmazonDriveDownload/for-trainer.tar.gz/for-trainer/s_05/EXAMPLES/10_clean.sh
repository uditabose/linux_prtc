./01_genmake.sh
rm -f Makefile
