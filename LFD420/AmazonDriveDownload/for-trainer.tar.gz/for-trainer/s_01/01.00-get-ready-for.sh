#wget http://bit.ly/LFready -O ready-for.sh
rm -f ready-for.sh
wget https://training.linuxfoundation.org/cm/prep/ready-for.sh
chmod 755 ready-for.sh
