make clean
./01_genmake.sh
rm -f Makefile
rm -f user.txt
rm -f sudo.txt
