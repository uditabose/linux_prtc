make clean
./02_genmake.sh
rm -f Makefile
rm -rf sparse
