make clean
#./01_genmake.sh
rm -f Makefile
rm -f add-symbol-file.gdb
