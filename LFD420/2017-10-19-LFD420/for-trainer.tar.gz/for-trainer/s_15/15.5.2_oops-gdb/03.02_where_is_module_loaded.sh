echo "+ sudo ./add-symbol-file.sh oops"
sudo ./add-symbol-file.sh oops
echo "+ cat add-symbol-file.gdb"
cat add-symbol-file.gdb
