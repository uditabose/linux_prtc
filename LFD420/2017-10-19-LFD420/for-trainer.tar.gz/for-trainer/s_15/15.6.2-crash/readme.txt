Ex: 

ps

task 1 - should be init

struct mm_struct

Ex:

task

search with / for mm and copy address

mm_struct <address from above>

now we should see mm_struct for this task

Ex:

p jiffies
p jiffies
whatis jiffies
p &jiffies
vtop <vitual address from before>
ptov <physical address from before>

Ex:

set (context)
log (to see kernel log)
ps
ps <PID> e.g ps 1 
vm <PID> e.g. vm 1
files <PID> e.g files 1
set <pid> e.g. set 1


