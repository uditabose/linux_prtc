/home/student/x61s/lfd320-staging/s_02/linux-4.3/tools/power/cpupower
build it
sudo make
sudo make install
