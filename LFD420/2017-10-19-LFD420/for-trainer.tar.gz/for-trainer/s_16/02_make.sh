make clean
make
#../sign-all.sh
