building kernel in s_02
