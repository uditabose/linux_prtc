make clean
#./01_genmake.sh
rm -f Makefile
rm -f HIST_1 HIST_2 HIST_3 HIST_4 HIST_5 perf.data perf.data.old
rm -f *hist*
