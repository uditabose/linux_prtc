extern void mod1fun(void);
