#!/bin/bash 

function plus_off {
  set +x
}
