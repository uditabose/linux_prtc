#/bin/bash 
# http://mywiki.wooledge.org/BashGuide/Practices/


function plus_on {
  set -x
}



